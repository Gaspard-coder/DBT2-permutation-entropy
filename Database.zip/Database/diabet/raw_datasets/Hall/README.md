# Mixed type 2 diabetic CGM Dataset

**Original paper**: Hall H, Perelman D, Breschi A, Limcaoco P, Kellogg R, McLaughlin T, et al. (2018) Glucotypes reveal new patterns of glucose dysregulation. PLoS Biol 16(7): e2005143. https://doi.org/10.1371/journal.pbio.2005143

## Dataset structure
├── DBT2\
│   ├── cgm_diabetics.csv (sorted csv with diabetic patients only)\
│   ├── DBT2_formatted (double .mat files with Ts = 15min)\
│   ├── DBT2_mat_table (table .mat files with original time stamps)\
│   ├── DBT2_mat_table_resampled (table .mat files resampled to 15min time stamps)\
│   └── subject_split_DBT2 (split of the cgm_diabetics.csv dataset by subject)\
├── NDBT2\
│   ├── cgm_normoglycemic.csv\
│   ├── NDBT2_formatted\
│   ├── NDBT2_mat_table\
│   ├── NDBT2_mat_table_resampled\
│   └── subject_split_NDBT2\
├── PDBT2\
│   ├── cgm_prediabetic.csv\
│   ├── PDBT2_formatted\
│   ├── PDBT2_mat_table\
│   ├── PDBT2_mat_table_resampled\
│   └── subject_split_PDBT2\
└── source\
│   ├── Cohort_characteristics_split_by_ADA_diagnosis.tiff\
│   ├── cohort_characteristics.tiff\
│   ├── glucotypes.pdf (original study)\
│   └──  raw_datas.csv

## Cohort caracteristics
"We recruited 57 healthy participants without prior diagnosis of diabetes. We monitored their blood glucose using CGM in their normal environment, and we extensively characterized them with clinical metabolic phenotypes including whole-body insulin resistance and insulin secretion.

The cohort composition was 32 females and 25 males, with an age range of 25 to 76 (median 51). On screening tests:
- 5 met criteria for having type 2 diabetes, defined as HbA1c ≥ 6.5%, fasting blood glucose ≥ 126 mg/dL, or 2-hour glucose during 75 gram OGTT ≥ 200 mg/dL; 
- 14 had prediabetes, defined as HbA1c > 5.7% and < 6.5%, fasting blood glucose 100–125 mg/dL, or 2-hour glucose during OGTT 140–199 mg/dL; 
- the remainder were normoglycemic, defined as fasting and 2-hour OGTT plasma glucose and HbA1c below the diagnostic thresholds for prediabetes and diabetes 

Please see `cohort_characteristics.tiff` and `Cohort_characteristics_split_by_ADA_diagnosis.tiff` and S2 Tables for details on the cohort"

The original sampling rate of the dataset is **5 minutes**.

## Sorting the dataset
Based on those criterias, we were able to sort the dataset into 3 groups:
- Type 2 diabetic (n=5): `1636-69-001; 1636-69-091; 2133-004; 2133-018; 2133-039`

- Prediabetic (n=14): `1636-69-026; 1636-69-032; 1636-69-090; 1636-69-114; 1636-70-1005; 1636-70-1010; 2133-015; 2133-017; 2133-019; 2133-021; 2133-024; 2133-027; 2133-035; 2133-036`
- Normoglycemic (n=38): the other participants

## Formatting for permutation entropy analysis
After sorting, converting and resampling the dataset, we obtained 57 .mat files (double format) with a sampling rate of 15 minutes, leading to around 700 samples per patient.
