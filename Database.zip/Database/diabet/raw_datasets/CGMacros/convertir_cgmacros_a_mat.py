# -*- coding: utf-8 -*-
"""
CGMacros -> MATLAB .mat
Clasifica cada sujeto en NDBT2 / PDBT2 / DBT2 segun HbA1c (criterio ADA)
y exporta un .mat por sujeto en subcarpetas por grupo.
"""
import os, re, glob, json
import numpy as np
import pandas as pd
from scipy.io import savemat

BASE = '/mnt/user-data/uploads/CGMacros'
OUT  = '/home/claude/work/MAT'

GRUPOS = {
    'NDBT2': 'No diabetico (HbA1c < 5.7 %)',
    'PDBT2': 'Prediabetes (HbA1c 5.7 - 6.4 %)',
    'DBT2' : 'Diabetes tipo 2 (HbA1c >= 6.5 %)',
}

def clasificar(a1c):
    if pd.isna(a1c): return None
    if a1c < 5.7:  return 'NDBT2'
    if a1c < 6.5:  return 'PDBT2'
    return 'DBT2'

# ---------- bio.csv ----------
bio = pd.read_csv(os.path.join(BASE, 'bio.csv'))
bio.columns = [c.strip() for c in bio.columns]
# desambiguar las tres columnas "Time (t)"
cols = list(bio.columns); k = 0
for i, c in enumerate(cols):
    if c == 'Time (t)':
        k += 1; cols[i] = f'Time_fingerstick_{k}'
bio.columns = cols
bio = bio.rename(columns={
    '#1 Contour Fingerstick GLU': 'Fingerstick_1',
    '#2 Contour Fingerstick GLU': 'Fingerstick_2',
    '#3 Contour Fingerstick GLU': 'Fingerstick_3',
})
bio['grupo'] = bio['A1c PDL (Lab)'].apply(clasificar)

BIO_MAP = [  # (campo .mat, columna bio.csv, unidad, descripcion)
 ('edad','Age','anios','Edad'),
 ('sexo','Gender','-','Sexo autoinformado (M/F)'),
 ('imc','BMI','kg/m^2','Indice de masa corporal'),
 ('peso_lb','Body weight','lb','Peso corporal'),
 ('altura_in','Height','in','Estatura'),
 ('etnia','Self-identify','-','Grupo etnico autoidentificado'),
 ('hba1c','A1c PDL (Lab)','%','Hemoglobina glicosilada (laboratorio)'),
 ('glucosa_ayunas','Fasting GLU - PDL (Lab)','mg/dL','Glucosa plasmatica en ayunas'),
 ('insulina','Insulin','uIU/mL','Insulina en ayunas'),
 ('trigliceridos','Triglycerides','mg/dL','Trigliceridos'),
 ('colesterol_total','Cholesterol','mg/dL','Colesterol total'),
 ('hdl','HDL','mg/dL','Colesterol HDL'),
 ('no_hdl','Non HDL','mg/dL','Colesterol no-HDL'),
 ('ldl','LDL (Cal)','mg/dL','Colesterol LDL (calculado)'),
 ('vldl','VLDL (Cal)','mg/dL','Colesterol VLDL (calculado)'),
 ('ratio_col_hdl','Cho/HDL Ratio','-','Cociente colesterol total / HDL'),
 ('hora_extraccion','Collection time PDL (Lab)','hh:mm:ss','Hora de extraccion de la muestra'),
 ('fingerstick_1','Fingerstick_1','mg/dL','Glucemia capilar Contour, medicion 1'),
 ('fingerstick_1_hora','Time_fingerstick_1','hh:mm','Hora de la medicion capilar 1'),
 ('fingerstick_2','Fingerstick_2','mg/dL','Glucemia capilar Contour, medicion 2'),
 ('fingerstick_2_hora','Time_fingerstick_2','hh:mm','Hora de la medicion capilar 2'),
 ('fingerstick_3','Fingerstick_3','mg/dL','Glucemia capilar Contour, medicion 3'),
 ('fingerstick_3_hora','Time_fingerstick_3','hh:mm','Hora de la medicion capilar 3'),
]

# ---------- esquema canonico de las series ----------
NUM_COLS = [  # (campo .mat, nombre canonico en csv, unidad, descripcion)
 ('libre_gl','Libre GL','mg/dL','Glucosa intersticial, Abbott FreeStyle Libre Pro (15 min, remuestreada a 1 min)'),
 ('dexcom_gl','Dexcom GL','mg/dL','Glucosa intersticial, Dexcom G6 Pro (5 min, remuestreada a 1 min)'),
 ('hr','HR','lpm','Frecuencia cardiaca (Fitbit Sense)'),
 ('calorias_actividad','Calories (Activity)','kcal','Gasto calorico por actividad (Fitbit Sense)'),
 ('mets','METs','MET','Equivalente metabolico de la tarea'),
 ('intensidad','Intensity','-','Intensidad de actividad (variante de METs)'),
 ('pasos','Steps','pasos','Pasos acumulados'),
 ('calorias_comida','Calories','kcal','Energia de la comida registrada'),
 ('hidratos','Carbs','g','Hidratos de carbono de la comida'),
 ('proteinas','Protein','g','Proteinas de la comida'),
 ('grasas','Fat','g','Grasas de la comida'),
 ('fibra','Fiber','g','Fibra de la comida'),
 ('azucar','Sugar','g','Azucares de la comida'),
 ('cantidad_consumida','Amount Consumed','% / porciones','Cantidad efectivamente consumida'),
]
TXT_COLS = [
 ('tipo_comida','Meal Type','-','Tipo de comida normalizado: breakfast/lunch/dinner/snack'),
 ('ruta_imagen','Image path','-','Ruta relativa de la fotografia del plato'),
]

MEAL_NORM = {'breakfast':'breakfast','lunch':'lunch','dinner':'dinner',
             'snack':'snack','snacks':'snack','snack 1':'snack'}

def norm_meal(x):
    if not isinstance(x, str): return ''
    s = x.strip().lower()
    return MEAL_NORM.get(s, s)

def to_num(s):
    return pd.to_numeric(s, errors='coerce').astype(float).to_numpy()

def cellstr(seq):
    return np.array([np.array([str(v)], dtype=object) if False else str(v) for v in seq], dtype=object).reshape(-1,1)

DATENUM_EPOCH = 719529.0  # datenum de 1970-01-01

resumen = []
for g in GRUPOS: os.makedirs(os.path.join(OUT, g), exist_ok=True)

archivos = sorted(glob.glob(os.path.join(BASE, 'CGMacros-*', 'CGMacros-*.csv')))
for f in archivos:
    nombre = os.path.splitext(os.path.basename(f))[0]      # CGMacros-001
    sid = int(nombre.split('-')[1])
    fila = bio[bio['subject'] == sid]
    if fila.empty:
        print('SIN BIO:', nombre); continue
    fila = fila.iloc[0]
    grupo = fila['grupo']

    d = pd.read_csv(f, low_memory=False)
    d.columns = [c.strip() for c in d.columns]
    d = d.drop(columns=[c for c in d.columns if c.startswith('Unnamed')], errors='ignore')
    presentes = list(d.columns)

    ts = pd.to_datetime(d['Timestamp'], errors='coerce')
    n = len(d)

    datos = {}
    datos['timestamp'] = np.array([t.strftime('%Y-%m-%d %H:%M:%S') if pd.notna(t) else ''
                                   for t in ts], dtype=object).reshape(-1,1)
    _secs = (ts - pd.Timestamp('1970-01-01')).dt.total_seconds()
    datos['datenum'] = (DATENUM_EPOCH + _secs/86400.0).to_numpy().reshape(-1,1)
    t0 = ts.min()
    datos['t_min'] = ((ts - t0).dt.total_seconds()/60.0).to_numpy().reshape(-1,1)

    ausentes = []
    for campo, col, _u, _dsc in NUM_COLS:
        if col in d.columns:
            datos[campo] = to_num(d[col]).reshape(-1,1)
        else:
            datos[campo] = np.full((n,1), np.nan)
            ausentes.append(col)
    for campo, col, _u, _dsc in TXT_COLS:
        if col in d.columns:
            v = d[col]
            v = v.map(norm_meal) if col == 'Meal Type' else v.fillna('').astype(str)
        else:
            v = pd.Series(['']*n); ausentes.append(col)
        datos[campo] = np.array([str(x) for x in v], dtype=object).reshape(-1,1)
    if 'Meal Type' in d.columns:
        datos['tipo_comida_original'] = np.array(
            [('' if pd.isna(x) else str(x)) for x in d['Meal Type']], dtype=object).reshape(-1,1)
    else:
        datos['tipo_comida_original'] = np.array(['']*n, dtype=object).reshape(-1,1)

    biod = {}
    for campo, col, _u, _dsc in BIO_MAP:
        v = fila[col] if col in fila.index else np.nan
        if isinstance(v, str) or campo.endswith('hora') or campo in ('sexo','etnia','hora_extraccion'):
            biod[campo] = '' if (v is None or (not isinstance(v,str) and pd.isna(v))) else str(v).strip()
        else:
            biod[campo] = float(v) if pd.notna(v) else np.nan

    sujeto = {
        'id': float(sid),
        'nombre': nombre,
        'grupo': grupo,
        'grupo_desc': GRUPOS[grupo],
        'archivo_origen': os.path.relpath(f, BASE).replace('\\','/'),
    }

    campos = [c[0] for c in NUM_COLS] + [c[0] for c in TXT_COLS]
    unidades = {c[0]: c[2] for c in NUM_COLS + TXT_COLS}
    descr    = {c[0]: c[3] for c in NUM_COLS + TXT_COLS}
    unidades.update({'timestamp':'-','datenum':'dias','t_min':'min'})
    descr.update({'timestamp':'Marca temporal local (texto)',
                  'datenum':'Marca temporal en formato datenum de MATLAB',
                  't_min':'Minutos transcurridos desde la primera muestra'})

    info = {
        'n_muestras': float(n),
        'periodo_muestreo_min': 1.0,
        't_inicio': ts.min().strftime('%Y-%m-%d %H:%M:%S'),
        't_fin':    ts.max().strftime('%Y-%m-%d %H:%M:%S'),
        'duracion_dias': float((ts.max()-ts.min()).total_seconds()/86400.0),
        'columnas_originales': np.array([str(c) for c in presentes], dtype=object).reshape(-1,1),
        'columnas_ausentes': (np.array([str(c) for c in ausentes], dtype=object).reshape(-1,1)
                              if ausentes else np.zeros((0,1), dtype=object)),
        'campos': np.array(list(datos.keys()), dtype=object).reshape(-1,1),
        'unidades': np.array([unidades.get(k,'-') for k in datos.keys()], dtype=object).reshape(-1,1),
        'descripcion': np.array([descr.get(k,'-') for k in datos.keys()], dtype=object).reshape(-1,1),
        'criterio_clasificacion': 'ADA: HbA1c < 5.7 % = NDBT2; 5.7-6.4 % = PDBT2; >= 6.5 % = DBT2',
        'fuente': 'CGMacros v1.0.0, PhysioNet (doi:10.13026/3z8q-x658), Gutierrez-Osuna, Kerr, Mortazavi y Das, 2025. Licencia CC BY-NC-SA 4.0',
    }

    dest = os.path.join(OUT, grupo, nombre + '.mat')
    savemat(dest, {'sujeto': sujeto, 'bio': biod, 'datos': datos, 'info': info},
            do_compression=True, oned_as='column', long_field_names=True)

    # ---- metricas para el informe ----
    gl = datos['libre_gl'].ravel(); dx = datos['dexcom_gl'].ravel()
    ref = gl if np.isfinite(gl).sum() >= np.isfinite(dx).sum() else dx
    val = ref[np.isfinite(ref)]
    meals = pd.Series(datos['tipo_comida'].ravel())
    meals = meals[meals != '']
    resumen.append(dict(
        sujeto=sid, nombre=nombre, grupo=grupo,
        edad=biod['edad'], sexo=biod['sexo'], imc=biod['imc'], etnia=biod['etnia'],
        hba1c=biod['hba1c'], glucosa_ayunas=biod['glucosa_ayunas'], insulina=biod['insulina'],
        trigliceridos=biod['trigliceridos'], colesterol=biod['colesterol_total'],
        hdl=biod['hdl'], ldl=biod['ldl'],
        n_muestras=n, dias=info['duracion_dias'],
        t_inicio=info['t_inicio'], t_fin=info['t_fin'],
        pct_libre=100*np.isfinite(gl).mean(), pct_dexcom=100*np.isfinite(dx).mean(),
        pct_hr=100*np.isfinite(datos['hr'].ravel()).mean(),
        pct_mets=100*np.isfinite(datos['mets'].ravel()).mean(),
        pct_intensidad=100*np.isfinite(datos['intensidad'].ravel()).mean(),
        n_comidas=int(len(meals)),
        n_desayuno=int((meals=='breakfast').sum()), n_almuerzo=int((meals=='lunch').sum()),
        n_cena=int((meals=='dinner').sum()), n_snack=int((meals=='snack').sum()),
        n_imagenes=int((pd.Series(datos['ruta_imagen'].ravel())!='').sum()),
        gl_media=float(np.mean(val)), gl_sd=float(np.std(val, ddof=1)),
        gl_cv=float(100*np.std(val, ddof=1)/np.mean(val)),
        gl_min=float(np.min(val)), gl_max=float(np.max(val)),
        gmi=float(3.31 + 0.02392*np.mean(val)),
        tir=float(100*np.mean((val>=70)&(val<=180))),
        tar=float(100*np.mean(val>180)), tbr=float(100*np.mean(val<70)),
        columnas_ausentes=';'.join(ausentes),
        kcal_dia=float(np.nansum(datos['calorias_comida'])/info['duracion_dias']),
        carb_dia=float(np.nansum(datos['hidratos'])/info['duracion_dias']),
        prot_dia=float(np.nansum(datos['proteinas'])/info['duracion_dias']),
        gras_dia=float(np.nansum(datos['grasas'])/info['duracion_dias']),
        fibra_dia=float(np.nansum(datos['fibra'])/info['duracion_dias']),
        tam_mat_kb=os.path.getsize(dest)/1024.0,
    ))
    print(f'{nombre}  {grupo:5s}  A1c={biod["hba1c"]:.1f}  n={n:6d}  {dest}')

df = pd.DataFrame(resumen)
df.to_csv('/home/claude/work/resumen_sujetos.csv', index=False)
print('\nTOTAL:', len(df))
print(df.groupby('grupo').size())
