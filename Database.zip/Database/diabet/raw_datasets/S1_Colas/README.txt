Base de datos de Glucemia
-------------------------
- Las señales originales se encuentran en el archivo pone.0225817.s001.zip.

- La carpeta S1_BKP contiene las señales procesadas según el criterio indicado en el archivo clinical_data.txt.

- Los valores de glucemia se encuentran en la 4ta columna.

- En S1_glucemia_4ta_columna, las señales marcadas como "DIA_xx.csv" (diabéticos) corrersponden a pacientes con test TRUE según el archivo clinical_data.txt. Asimismo las marcadas con "NOR_xx.csv" (normales) corresponden a FALSE. Las señales que comienzan con una "X_" contienen registros con valores nulos "NA", hay 34 señales de este tipo. Contienen una sola columna con los valores de glucemia de las señales originales. Hay 34 señales marcadas con "X_" que contienen registros "NA" de glucemia.

- La carpeta S1 contiene las señales con una sola columna con los valores de glucemia y sin registros NA clasificadas.
